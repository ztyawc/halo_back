---
title: JavaWeb-Day-01
categories: 学习
tags: JavaWeb
---

## Maven

下载安装解压

配置环境变量

- M2_HOME            maven目录下的bin目录
- MAVEN_HOME    maven目录

修改mirrors（镜像）为阿里云地址

```
<mirror>
    <id>aliyunmaven</id>
    <mirrorOf>*</mirrorOf>
    <name>阿里云公共仓库</name>
    <url>https://maven.aliyun.com/repository/public</url>
</mirror>
```

## ServletContext

- 共享数据

```java
public class HelloServlet extends HttpServlet {
    

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        ServletContext context = this.getServletContext();
        String name= (String) context.getAttribute("name");
        response.setContentType("html/text;utf-8");
        response.setCharacterEncoding("utf-8");
        response.getWriter().println(name);
    }
    

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    }
    
    
    
    
public class ServletWrite extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name="张天宇";
        ServletContext context=this.getServletContext();
        context.setAttribute("name",name);

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
```

- 获取初始化参数

配置xml文件

```java
    <context-param>
        <param-name>name</param-name>
        <param-value>zhangtianyu</param-value>
    </context-param>
```

获取

```java
public class ServletParamter extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ServletContext context = this.getServletContext();
        String name=context.getInitParameter("name");
        response.getWriter().println(name);

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
```

- 请求转发

```java
public class ServletDispather extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ServletContext context = this.getServletContext();
        context.getRequestDispatcher("/index.jsp").forward(request,response);

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
```

- 读取资源文件