---
title: 【Magisk】雷电安卓9模拟器安装Magisk
categories: Magisk
---

### 本教程为 安卓9模拟器(Android_9 x86_64) 安装 面具(Magisk)



#### 方法1--------自带本地安装（可能是旧版）

1. 设置 > 其他设置 > 开启root权限
2. 启动模拟器并安装Magisk Terminal Emulator.apk、Magisk.apk
   打开Magisk Terminal Emulator <M> <回车> <Y> <回车> 超级用户授权允许
3. <1> <回车> <A> <回车> <1> <回车>
4. 设置 > 其他设置 > 关闭root权限 并重启模拟器 安装完成

#### 方法2--------在线安装最新版（需要梯子）

1. 设置 > 其他设置 > 开启root权限 （开梯子，不管用什么方法，反正要让模拟器能翻）
2. 启动模拟器并安装Magisk Terminal Emulator.apk、Magisk.apk
   打开Magisk Terminal Emulator <M> <回车> <Y> <回车> 超级用户授权允许
3. <1> <回车> <1> <回车> 等待下载 <1> <回车>
4. 设置 > 其他设置 > 关闭root权限 并重启模拟器 安装完成

#### 方法3--------离线安装最新版

1. 设置 > 其他设置 > 开启root权限，复制app-debug.apk到共享目录
2. 启动模拟器并安装Magisk Terminal Emulator.apk、Magisk.apk
   打开Magisk Terminal Emulator <M> <回车> <Y> <回车> 超级用户授权允许
   <1> <回车> <X> <回车>   输入/sdcard/Pictures/app-debug.apk <回车> <1> <回车>
3. 设置 > 其他设置 > 关闭root权限 并重启模拟器 安装完成



[下载地址](https://wwm.lanzouy.com/ikCdn0ajoeng)