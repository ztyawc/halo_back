---
title: JavaWeb-Day-02
categories: 学习
tags: JavaWeb
---

## HttpServletResponse

### 重定向

一个web资源收到客户端请求后，他会通知客户端去访问另一个web资源，这就是重定向

- 用户登录

```java
response.sendRedirect("index.jsp");
```

- 案列
- jsp页面

```jsp
<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <title>JSP - Hello World</title>
</head>

<body>
<%--//动态前缀--%>
<form action="${pageContext.request.contextPath}/ServletLogin" method="get">
    账号：<input type="text" name="username"><br>
    密码：<input type="password" name="password"><br>
    <input type="submit" value="提交">

</form>
</body>
</html>
```

- servlet

```java
public class ServletLogin extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //设置中文
        response.setContentType("text/html;charset=UTF-8");
        String username = request.getParameter("username");
        if (username.equals("zty")){
            response.getWriter().println("欢迎你"+username);

        }else {
            response.sendRedirect("index.jsp");
        }

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        super.doGet(request,response);
    }
}
```

## HttpServletRequest

- 获取前端传递的参数

```java
//获取单个参数
request.getParameter()
//获取多个参数
request.getParameterValues()
```

- 案列
- jsp页面

```jsp
<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <title>JSP - Hello World</title>
</head>

<body>
<%--//动态前缀--%>
<form action="${pageContext.request.contextPath}/ServletLogin" method="get">
    账号：<input type="text" name="username"><br>
    密码：<input type="password" name="password"><br>
    <input type="checkbox" name="box" value="唱">唱<br>
    <input type="checkbox" name="box" value="跳">跳<br>
    <input type="checkbox" name="box" value="rap">rap<br>
    <input type="checkbox" name="box" value="篮球">篮球<br>
    <input type="submit" value="提交">
</form>
</body>
</html>
```

- servlet

```java
public class ServletLogin extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //设置中文
        response.setContentType("text/html;charset=UTF-8");
        //获取单个值
        String username = request.getParameter("username");
        //获取多个值
        String[] usernames = request.getParameterValues("box");
        if (username.equals("zty")){
            response.getWriter().println("欢迎你"+username);
            //遍历输出数组
            response.getWriter().println(Arrays.toString(usernames));

        }else {
            request.getRequestDispatcher("index.jsp").forward(request,response);
        }

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        super.doGet(request,response);
    }
}
```

