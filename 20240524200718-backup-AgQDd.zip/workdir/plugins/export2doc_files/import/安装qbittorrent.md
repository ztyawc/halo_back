### 安装qbittorrent



```shell
apt update -y && apt upgrade -y
apt install qbittorrent-nox -y
vim /etc/systemd/system/qbittorrent-nox.service

[Unit]
Description=qBittorrent Command Line Client
After=network.target

[Service]
Type=forking
User=root
Group=root
UMask=007
ExecStart=/usr/bin/qbittorrent-nox -d --webui-port=8080
Restart=on-failure

[Install]
WantedBy=multi-user.target


systemctl daemon-reload && systemctl enable qbittorrent-nox
systemctl start qbittorrent-nox
systemctl status qbittorrent-nox
```

安装完成后通过 ip:8080 访问即可，默认用户名 密码分别为admin adminadmin



### docker版（推荐）



```shell
docker run -d \
  --name=qbittorrent \
  --network host \
  -e PUID=1000 \
  -e PGID=1000 \
  -e TZ=Asia/Shanghai \
  -e WEBUI_PORT=8899 \
  -v /opt/config/qbittorrent//config:/config \
  -v /opt/Download/qbittorrent:/downloads \
  --restart unless-stopped \
lscr.io/linuxserver/qbittorrent:latest
```

端口：8899   密码：docker logs 容器id



### 安装



```shell
curl https://rclone.org/install.sh | sudo bash

//gui面板

nohup rclone rcd --rc-web-gui --rc-user=ztyawc --rc-pass=zty123456 --rc-addr=:5573 &

//传输文件
rclone copy -P /root/Download ztyawc:/qb --transfers=8
```



