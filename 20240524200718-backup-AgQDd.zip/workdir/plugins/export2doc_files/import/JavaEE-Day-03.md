---
title: JavaEE-Day-03
categories: 学习
tags: JavaEE
---

## Date类

```java
    public void test(){
        Date date = new Date();                //构造器一:获取当前时间的Date对象
        System.out.println(date.toString());   //返回当前时间
        System.out.println(date.getTime());    //返回当前时间戳
    }
}
```

### SimpleDateFormat

```
    public void test(){
        Date date = new Date();
        SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat("yyyy年:MM月:dd日 hh:mm:ss");
        String format = simpleDateFormat1.format(date);
        System.out.println(format);
    }
```

