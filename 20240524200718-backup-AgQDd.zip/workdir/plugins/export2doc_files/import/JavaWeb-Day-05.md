---
title: JavaWeb-Day-05
categories: 学习
tags: JavaWeb
---

## MVC

什么是mvc：Model        View        Controller  模型、视图、控制器

Model

- 业务处理：业务逻辑（Service）
- 数据持久层：CRUD（Dao）

View

- 展示数据
- 提供链接发起Servlet请求（a、form、img...）

Controller（Servlet）

- 接收用户的请求（req：请求参数、Session信息）
- 交给业务层处理相应代码
- 控制视图的跳转

```
登录--->接收用户的登录请求--->处理用户的请求（获取用户登录的参数、username、password）--->交给业务
层处理登录业务（判断用户名、密码是否正确）--->Dao层查询查询用户名、密码是否正确--->数据库
```

### Filter（过滤器）

Filter：用来过滤网站的数据

- 处理中文乱码
- 登录验证等

![image-20220605114126239](C:\Users\35626\AppData\Roaming\Typora\typora-user-images\image-20220605114126239.png)

1. **实例**

- **设置统一编码**
- **jsp页面**

```jsp
<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <title>JSP - Hello World</title>
</head>
<body>
<form action="${pageContext.request.contextPath}/servlet/hello" method="get">
    账号：<input type="text" name="username"><br>
    密码：<input type="password" name="password">
    <input type="submit" value="提交">
</form>
</body>
</html>
```

- **servlet**

```java
@WebServlet(name = "helloServlet", value = "/servlet/hello")
public class HelloServlet extends HttpServlet {
    private String message;

    public void init() {
        message = "Hello World!";
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {

        // Hello
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h1>" + message + "</h1>");
        out.println("</body></html>");
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        out.println("账号为："+username+"<br>");
        out.println("密码为："+password+"<br>");
    }

    public void destroy() {
    }
}
```

- **Filter**

```java
//name等同于<filter-name>，urlPatterns等同于<url-pattern>
@WebFilter(filterName = "EncodingFilter",urlPatterns = "/servlet/*")
public class EncodingFilter implements Filter {
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws ServletException, IOException {
        //设置编码
        response.setContentType("text/html;charset=utf-8");
        response.setCharacterEncoding("utf-8");
        request.setCharacterEncoding("utf-8");
        System.out.println("放行前");
        //放行
        chain.doFilter(request,response);
        System.out.println("放行后");


    }
}
```

### JDBC

需要的jar包：

- java.sql
- javax.sql
- mysql-conneter-java(驱动)

```java
public class jdbc {
    public static void main(String[] args) throws ClassNotFoundException, SQLException {
        //加载类
        Class.forName("com.mysql.jdbc.Driver");
        //设置url
        String url="jdbc:mysql://localhost:3306/jdbc";
        //链接数据库
        Connection connection = DriverManager.getConnection(url, "root", "");
        //向数据库发生sql对象
        Statement statement = connection.createStatement();
        //编写sql语句
        String sql="select * from jdbc.users";
        //执行查询sql，返回一个ResultSet集
        ResultSet resultSet = statement.executeQuery(sql);
        while (resultSet.next()){
            System.out.println(resultSet.getObject("id"));
            System.out.println(resultSet.getObject("name"));
            System.out.println(resultSet.getObject("password"));
            System.out.println(resultSet.getObject("address"));
        }
        //关闭资源
        resultSet.close();
        statement.close();
        connection.close();

    }
}
```

```java
statement.executeQuery()//查询操作 返回ResultSet
statement.executeUpdate() //操作增删改 返回一个受影响的行数
statement.execute()       //可以执行任何操作，效率较低
statement.executeBath()   //可以放入多个sql语句

```

#### 工具类，实现增删改查

- 先将mysql连接配置文件放入**db.properties**文件中，位于src目录下

```properties
driver=com.mysql.jdbc.Driver
url=jdbc:mysql://localhost:3306/jdbc?useUnicode=true&characterEncoding=utf8
username=root
password=
```

- 创建工具类

```java
public class JdbcUtils {

    private static String driver=null;
    private static String url=null;
    private static String username=null;
    private static String password=null;

    static {
        try {
            FileInputStream in = new FileInputStream("/db.properties");
            Properties properties = new Properties();
            properties.load(in);
            driver=properties.getProperty("driver");
            url=properties.getProperty("url");
            username=properties.getProperty("username");
            password=properties.getProperty("password");
            //驱动只用加载一次
            Class.forName(driver);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    //获取链接
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(url,username,password);
    }
    //释放资源
    public static void resultSet(Connection conn ,Statement st,ResultSet rs) throws SQLException {
        if (conn!=null){
            conn.close();
        }
        if (st!=null){
            st.close();
        }if (rs!=null){
            rs.close();
        }
    }
}
```

- **增**

```java
public class test {
    public static void main(String[] args) throws SQLException {
        Connection conn=null;
        Statement st=null;
        ResultSet rs=null;
        try {
            conn=JdbcUtils.getConnection();
            st=conn.createStatement();
            String sql="insert into jdbc.users (id, name, password, address) values (26,'张天宇','147','太原')";
            int i=st.executeUpdate(sql);
            if (i>0){
                System.out.println("插入成功");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            JdbcUtils.resultSet(conn,st,rs);
        }
    }
}
```

- **删**

```java
public class rm {
    public static void main(String[] args) throws SQLException {
        Connection conn=null;
        Statement st=null;
        ResultSet rs=null;
        try {
            conn=JdbcUtils.getConnection();
            st=conn.createStatement();
            String sql="delete from jdbc.users where id=26";
            int i=st.executeUpdate(sql);
            if (i>0){
                System.out.println("删除成功");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            JdbcUtils.resultSet(conn,st,rs);
        }
    }
}
```

- **改**

```java
public class ud {
    public static void main(String[] args) throws SQLException {
        Connection conn=null;
        Statement st=null;
        ResultSet rs=null;
        try {
            conn=JdbcUtils.getConnection();
            st=conn.createStatement();
            String sql="UPDATE jdbc.users SET name='王四' where id=1";
            int i=st.executeUpdate(sql);
            if (i>0){
                System.out.println("修改成功");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            JdbcUtils.resultSet(conn,st,rs);
        }
    }
}
```

**以上操作都是使用executeUpdate()**

- **查**

```java
public class TestSelect {
    public static void main(String[] args) throws SQLException {
        Connection conn=null;
        Statement st=null;
        ResultSet rs=null;
        try {
            conn = JdbcUtils.getConnection();
            st=conn.createStatement();
            String sql="select * from jdbc.users where id=1";
            rs=st.executeQuery(sql);
            while (rs.next()){
                //获取名字
                System.out.println(rs.getObject("name"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            JdbcUtils.resultSet(conn,st,rs);
        }
    }
}
```

#### SQL**注入**

**sql的漏洞，容易被攻击，导致数据泄露**

```java
public class SqlZr {
    public static void main(String[] args) throws SQLException {
        //正常获取     login("张天宇","123");
        //名字或1=1为true任意满足一个即可获取
        login("'or' 1=1","'or' 1=1");

    }
    public static void login(String username ,String password) throws SQLException {
        Connection conn=null;
        Statement st=null;
        ResultSet rs=null;
        try {
            conn = JdbcUtils.getConnection();
            st=conn.createStatement();
            String sql="select * from jdbc.users where name='"+username+"' and password='"+password+"'";
            rs=st.executeQuery(sql);
            while (rs.next()){
                //获取名字
                System.out.println(rs.getObject("name"));
                System.out.println(rs.getObject("password"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            JdbcUtils.resultSet(conn,st,rs);
        }
    }
}
```

#### PreparedStatement对象

**可以防止sql注入，并且效率更高**

- **实列**
- **增**

```java
public class add {
    public static void main(String[] args) throws SQLException {
        Connection conn=null;
        PreparedStatement st=null;
         conn = JdbcUtils.getConnection();
         //区别 使用占位符替代参数
         String sql="insert into jdbc.users (id, name, password, address) VALUES (?, ?, ?, ?)";
         st= conn.prepareStatement(sql);//预编译swl 先写，不执行
        //手动给参数赋值
        st.setInt(1,1);
        st.setString(2,"张三");
        st.setString(3,"110");
        st.setString(4,"大同");
        //执行
        int i = st.executeUpdate();
        if (i>0){
            System.out.println("插入成功");
        }
        JdbcUtils.resultSet(conn,st,null);
    }
}
```

- **删**

```java
public class delet {
    public static void main(String[] args) throws SQLException {
        Connection conn=null;
        PreparedStatement st=null;
        conn = JdbcUtils.getConnection();
        //区别 使用占位符替代参数
        String sql="delete from jdbc.users where id=?";
        st= conn.prepareStatement(sql);//预编译swl 先写，不执行
        //手动给参数赋值
        st.setInt(1,2);
        //执行
        int i = st.executeUpdate();
        if (i>0){
            System.out.println("删除成功");
        }
        JdbcUtils.resultSet(conn,st,null);
    }
}
```

- **改**

```java
public class UD {
    public static void main(String[] args) throws SQLException {
        Connection conn=null;
        PreparedStatement st=null;
        conn = JdbcUtils.getConnection();
        //区别 使用占位符替代参数
        String sql="update jdbc.users set password=? where id=?";
        st= conn.prepareStatement(sql);//预编译swl 先写，不执行
        //手动给参数赋值
        st.setString(1,"666");
        st.setInt(2,1);
        //执行
        int i = st.executeUpdate();
        if (i>0){
            System.out.println("修改成功");
        }
        JdbcUtils.resultSet(conn,st,null);
    }
}
```

- **查**

```java
public class select {
    public static void main(String[] args) throws SQLException {
        Connection conn=null;
        PreparedStatement st=null;
        ResultSet rs=null;
        conn=JdbcUtils.getConnection();
        String sql="select * from jdbc.users where id=?";
        st=conn.prepareStatement(sql);
        st.setInt(1,1);
        rs = st.executeQuery();
        while (rs.next()){
            System.out.println(rs.getObject("name"));
            System.out.println(rs.getObject("password"));
            System.out.println(rs.getObject("address"));
        }
        JdbcUtils.resultSet(conn,st,rs);
    }
}
```
