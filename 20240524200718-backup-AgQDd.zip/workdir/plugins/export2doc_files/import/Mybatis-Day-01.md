---
title: Mybatis-Day-01
categories: 学习
tags: Mybatis
---

## 第一个Mybatis程序

### 搭建环境

1. 创建数据库
2. 新建项目

新建一个maven项目

删除src目录

安装依赖

```xml
<dependencies>
    <dependency>
        <groupId>mysql</groupId>
        <artifactId>mysql-connector-java</artifactId>
        <version>5.0.7</version>
    </dependency>
    <dependency>
        <groupId>junit</groupId>
        <artifactId>junit</artifactId>
        <version>4.12</version>
        <scope>test</scope>
    </dependency>
    <dependency>
        <groupId>org.mybatis</groupId>
        <artifactId>mybatis</artifactId>
        <version>3.5.2</version>
    </dependency>
</dependencies>
```

### 创建一个模块

- 编写mybatis核心配置文

![](https://cdn.jsdelivr.net/gh/ztyawc/imgs/img/2022-06-08_144303.png)

```xml
<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE configuration
  PUBLIC "-//mybatis.org//DTD Config 3.0//EN"
  "http://mybatis.org/dtd/mybatis-3-config.dtd">
<configuration>
  <environments default="development">
    <environment id="development">
      <transactionManager type="JDBC"/>
      <dataSource type="POOLED">
        <property name="driver" value="${driver}"/>
        <property name="url" value="${url}"/>
        <property name="username" value="${username}"/>
        <property name="password" value="${password}"/>
      </dataSource>
    </environment>
  </environments>
  <mappers>
    <mapper resource="org/mybatis/example/BlogMapper.xml"/>
  </mappers>
</configuration>
```

- 编写mybatis工具类

![](https://cdn.jsdelivr.net/gh/ztyawc/imgs/img/2022-06-08_145746.png)

```java
public class MyBatisUtil {
    private static SqlSessionFactory sqlSessionFactory;
    static {
        try {


            String resource = "mybatis-config.xml";
            InputStream inputStream = Resources.getResourceAsStream(resource);
             sqlSessionFactory= new SqlSessionFactoryBuilder().build(inputStream);
        }catch (IOException e){
            e.printStackTrace();
        }
    }
    public SqlSession getSqlSession(){
        return sqlSessionFactory.openSession();
    }
}
```

###  编写代码

- 实体类

- Dao接口

```java
public interface UserDao {
    List<User> getUserList();
}
```

- 接口实现类由原来的UserDaoImpl转换为一个Mapper配置文件

```xml
<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE mapper
        PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
        "http://mybatis.org/dtd/mybatis-3-mapper.dtd">
<mapper namespace="com.zty.dao.UserDao">
<select id="getUserList" resultType="com.zty.pojo.User">
    select * from mybatis.user
</select>
</mapper>
```

### 测试

```java
public class UserDaoTest {
    @Test
    public void test(){
        SqlSession sqlSession = MyBatisUtil.getSqlSession();
        UserDao mapper = sqlSession.getMapper(UserDao.class);
        List<User> userList = mapper.getUserList();
        for (User user : userList) {
            System.out.println(user);
        }
    }
}
```

### 注解容易出错的点

maven依赖中mysql尽量使用高版本

配置过滤文件到测试目录等

```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <groupId>org.example</groupId>
    <artifactId>myBatis</artifactId>
    <packaging>pom</packaging>
    <version>1.0-SNAPSHOT</version>
    <modules>
        <module>mybatis-01</module>
    </modules>
    <dependencies>
    <dependency>
        <groupId>mysql</groupId>
        <artifactId>mysql-connector-java</artifactId>
        <version>5.1.47</version>
    </dependency>
    <dependency>
        <groupId>junit</groupId>
        <artifactId>junit</artifactId>
        <version>4.12</version>
        <scope>test</scope>
    </dependency>
    <dependency>
        <groupId>org.mybatis</groupId>
        <artifactId>mybatis</artifactId>
        <version>3.5.2</version>
    </dependency>
</dependencies>
    <properties>
        <maven.compiler.source>8</maven.compiler.source>
        <maven.compiler.target>8</maven.compiler.target>
    </properties>
    <build>
        <resources>
            <resource>
                <directory>src/main/resources</directory>
                <includes>
                    <include>**/*.properties</include>
                    <include>**/*.xml</include>
                </includes>
                <filtering>true</filtering>
            </resource>
            <resource>
                <directory>src/main/java</directory>
                <includes>
                    <include>**/*.properties</include>
                    <include>**/*.xml</include>
                </includes>
                <filtering>true</filtering>
            </resource>
        </resources>
    </build>
</project>
```

mysql数据库链接

```
jdbc:mysql://localhost:3306/mybatis?useSSL=false
```

### CRUD

- 根据id查询用户

```java
    //根据ID查询用户
    User getUserById(int id);
```



```java
    @Test
    public void testgetUserById(){
        SqlSession sqlSession = MyBatisUtil.getSqlSession();
        UserDao mapper = sqlSession.getMapper(UserDao.class);
        User user = mapper.getUserById(2);
        System.out.println(user);
        sqlSession.close();
    }
```

- 添加用户

**增删改需要提交事务**

```java
    //添加用户
    int addUser(User user);

//类型为实体类
<insert id="addUser" parameterType="com.zty.pojo.User">
    insert into mybatis.user (id, name, pwd) VALUES (#{id},#{name},#{pwd})
</insert>
```

```java
//添加用户
@Test
    public void addUser(){
        SqlSession sqlSession = MyBatisUtil.getSqlSession();
        UserDao mapper = sqlSession.getMapper(UserDao.class);
        mapper.addUser(new User(6,"反对","123"));
        sqlSession.commit();
        sqlSession.close();
    }
```

- 删除用户

```java
//删除用户
int rmUser(int id);
</insert>
    <delete id="rmUser" parameterType="int">
        delete from mybatis.user where id=#{id}
    </delete>
```

```java
//删除用户
@Test
public void rmUser(){
    SqlSession sqlSession = MyBatisUtil.getSqlSession();
    UserDao mapper = sqlSession.getMapper(UserDao.class);
    mapper.rmUser(1);
    sqlSession.commit();
    sqlSession.close();
}
```

- 修改用户

```java
//更新用户
int setUser(User user);

    <update id="setUser" parameterType="com.zty.pojo.User">
        update mybatis.user set name=#{name},pwd=#{pwd} where id=#{id}
    </update>
```

```java
//根据id修改id
@Test
public void testSet(){
    SqlSession sqlSession = MyBatisUtil.getSqlSession();
    UserDao mapper = sqlSession.getMapper(UserDao.class);
    mapper.setUser(new User(2,"sd","33"));
    sqlSession.commit();
    sqlSession.close();
}
```

### Map

```java
//map 名字 查询
User getUserById2(Map<String,Object> map);
//map 添加用户
int addUser1(Map<String,Object> map);
//map 删除用户
int rmUser1(Map<String,Object> map);
//map 修改用户
int setUser1(Map<String,Object> map);
```

```java
//map根据id查用户
@Test
public void testgetUserById3(){
    SqlSession sqlSession = MyBatisUtil.getSqlSession();
    UserDao mapper = sqlSession.getMapper(UserDao.class);
    Map<String,Object> map=new HashMap<String,Object>();
    map.put("name","sd");
    map.put("id",2);
    User user = mapper.getUserById2(map);
    System.out.println(user);
    sqlSession.close();
}

//map 自定义添加用户
@Test
public void addUser1(){
    SqlSession sqlSession = MyBatisUtil.getSqlSession();
    UserDao mapper = sqlSession.getMapper(UserDao.class);
    Map<String,Object> map=new HashMap<String,Object>();
    map.put("id1",29);
    map.put("pwd1","8");
    mapper.addUser1(map);
    sqlSession.commit();
    sqlSession.close();
}
//map 自定义删除用户
@Test
public void rmuser1(){
    SqlSession sqlSession = MyBatisUtil.getSqlSession();
    UserDao mapper = sqlSession.getMapper(UserDao.class);
    Map<String,Object> map=new HashMap<String,Object>();
    map.put("id",28);
    mapper.rmUser1(map);
    sqlSession.commit();
    sqlSession.close();
}

//map 自定义修改用户
@Test
public void sett(){
    SqlSession sqlSession = MyBatisUtil.getSqlSession();
    UserDao mapper = sqlSession.getMapper(UserDao.class);
    Map<String,Object> map=new HashMap<String,Object>();
    map.put("name","张天宇");
    map.put("id",6);
    mapper.setUser1(map);
    sqlSession.commit();
    sqlSession.close();
}
```

```xml
<select id="getUserById2" parameterType="Map" resultType="com.zty.pojo.User">
    select * from mybatis.user where name=#{name} and id=#{id}
</select>

<insert id="addUser1" parameterType="com.zty.pojo.User">
    insert into mybatis.user (id, name, pwd) VALUES (#{id1},#{name1},#{pwd1})
</insert>

<delete id="rmUser1" parameterType="com.zty.pojo.User">
    delete from mybatis.user where id=#{id}
</delete>
<update id="setUser1" parameterType="com.zty.pojo.User">
    update mybatis.user set name=#{name} where id=#{id}
</update>
```

### 模糊查询

```java
<select id="getLike" resultType="com.zty.pojo.User">
select * from mybatis.user where name like #{value}
</select>
```

```java
//模糊查询
@Test
public void getLike1(){
    SqlSession sqlSession = MyBatisUtil.getSqlSession();
    UserDao mapper = sqlSession.getMapper(UserDao.class);
    List<User> like = mapper.getLike("%反%");
    for (User user : like) {
        System.out.println(user);
    }
}
```