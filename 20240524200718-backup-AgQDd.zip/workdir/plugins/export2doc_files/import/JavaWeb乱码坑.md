## JavaWeb乱码坑



- jsp页面乱码只需在最开头加入

```jsp
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
```

- servlet页面乱码

​	设置响应格式

```
response.setContentType("text/html; charset=UTF-8");
response.setCharacterEncoding("UTF-8");
```

- servlet控制台乱码

​	在配置Tomcat页面的虚拟机那里填入命令

```
-Dfile.encoding=UTF-8
```

