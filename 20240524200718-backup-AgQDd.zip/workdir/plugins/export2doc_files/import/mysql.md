### 常用命令

```mysql
show databases					-- 查看所有数据库
use test						-- 使用数据库test
show tables 					-- 查看数据库中所有的表
describe db						-- 查看表的所有数据
create database test1			-- 创建数据库
drop database test1				-- 删除数据库
```

### 创建表

```mysql
CREATE TABLE student (
  `id` INT(4) COMMENT '学号',
  `name` VARCHAR(120) COMMENT '姓名',
  `birth` DATETIME COMMENT '出生日期',
  `address` VARCHAR(120) COMMENT '地址',
  `mail` VARCHAR(120) COMMENT '电子邮箱',
  PRIMARY KEY (`id`)
) CHARACTER SET utf8 COLLATE utf8_general_ci;

```

### 修改表

```mysql
ALTER TABLE student
MODIFY `name` VARCHAR(255) COMMENT '姓名';

```

### JDBC

```java
package JDBC;

import java.sql.*;

public class demo1 {
    public static void main(String[] args) throws ClassNotFoundException, SQLException {
        //加载驱动
        Class.forName("com.mysql.jdbc.Driver");
        String url="jdbc:mysql://1.15.155.221:3310/mysql?useUnicode=true&characterEncoding=utf8&useSSL=false";
        String username="root";
        String password="123456";
        //建立连接
        Connection connection= DriverManager.getConnection(url,username,password);
        Statement statement = connection.createStatement();

        String sql ="select * from student";
        //返回结果集
        ResultSet resultSet = statement.executeQuery(sql);
        
        //获取内容
        while (resultSet.next()){

            System.out.println(resultSet.getObject("address"));
        }
    }
}

```



