## Servlet

- 动态web技术





- 编写一个类继承HttpServlet，然后重写doGet，doPost（根据自己的需求）

```java
public class HelloServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        PrintWriter writer = resp.getWriter();
        writer.println("hello.张天宇");

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    }
}
```

- 编写Servlet映射类

  ```
  <!DOCTYPE web-app PUBLIC
   "-//Sun Microsystems, Inc.//DTD Web Application 2.3//EN"
   "http://java.sun.com/dtd/web-app_2_3.dtd" >
  
  <web-app>
    <display-name>Archetype Created Web Application</display-name>
    
    
    
    
    <servlet>
      <servlet-name>hello</servlet-name>
      <servlet-class>com.zty.HelloServlet</servlet-class>
    </servlet>
    <servlet-mapping>
      <servlet-name>hello</servlet-name>
      <url-pattern>/hello</url-pattern>
    </servlet-mapping>
  </web-app>
  ```

## ServletContext

web容器在启动的时候，他会为每个web程序都创建一个对应的ServletContext对象，它代表了当前的web应用

- 共享数据
- 