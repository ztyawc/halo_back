#### OkHttp

```java
package org.example;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class OkHttpExample {
    public static void main(String[] args) {

        //创建一个okhttp对象
        OkHttpClient okHttpClient = new OkHttpClient();
        //创建一个请求对象
        Request request = new Request.Builder().url("https://www.yaohuo.me").build();
        try {
            Response response = okHttpClient.newCall(request).execute();
            String body = response.body().string();


            FileWriter fileWriter = new FileWriter("D:\\yaohuo.html");
            fileWriter.write(body);
            //关闭流
            fileWriter.close();

            System.out.println(body);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }
}

```

