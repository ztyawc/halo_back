---
title: JavaWeb-Day-03
categories: 学习
tags: JavaWeb
---

## Cookies、Session

### Cookie

- **案列**
- **servlet**

```java
public class CookiesServletDemo extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //设置中文
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("utf-8");
        response.setCharacterEncoding("utf-8");
        //输出流
        PrintWriter out=response.getWriter();
        //获取cookie
        Cookie[] cookies = request.getCookies();
        //判断是否存在cookie
        if (cookies!=null){
            out.write("上一次访问时间是：");
            //获取每一个cookie
            for (int i = 0; i < cookies.length; i++) {
                Cookie cookie = cookies[i];
                //获取设置的cookie的值
                if (cookie.getName().equals("sj")){
                    //把获取的cookie的值转换为长整形
                    long l = Long.parseLong(cookie.getValue());
                    //变为Date类方便解析
                    Date date = new Date(l);
                    out.write(test(date));
                }
            }
        }else {
            out.println("第一次访问");
        }
        //新建cookie
        Cookie cookie = new Cookie("sj", System.currentTimeMillis() + "");
        //设置cookie时长(秒)
        cookie.setMaxAge(60);
        //添加cookie
        response.addCookie(cookie);


    }
    //解析方法
    public String test(Date date){
        SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat("yyyy年:MM月:dd日 hh:mm:ss");
        String format = simpleDateFormat1.format(date);
        return format;
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
```

- **jsp**

```jsp
<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<html>
<body>
<h2>Hello World!</h2>
<a href="cookie">点我</a><br>
<a href="RmServletCookie">点我删除cookie</a>
</body>
</html>
```

- **删除cookie**

```java
@WebServlet(name = "RmServletCookie", value = "/RmServletCookie")
public class RmServletCookie extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //设置一模一样的cookie
        //将时长设置为0后，添加
        Cookie cookie = new Cookie("sj", System.currentTimeMillis() + "");
        cookie.setMaxAge(0);
        response.addCookie(cookie);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
```

### Session(重点)

服务器会对每一个用户创建一个session

**可以传入对象**

- **实例**

- **jsp页面**

```jsp
<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<html>
<body>
<a href="ServletSession">查看</a><br>
<a href="s2">注销session</a><br>

</body>
</html>

```

- **创建session**

```java
@WebServlet(name = "ServletSession", value = "/ServletSession")
public class ServletSession extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=utf-8");
        PrintWriter out=response.getWriter();
        //获取session
        HttpSession session = request.getSession();
        //往session里添加值
        session.setAttribute("name","张天宇");
        String id = session.getId();
        if (session.isNew()){
            out.write("session创建成功 ID为："+id);
        }else {
            out.write("session ID:"+id);
            out.write("名字是"+session.getAttribute("name"));
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}

```

- **创建session(对象类型)**

```java
@WebServlet(name = "s1", value = "/s1")
public class s1 extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=utf-8");
        PrintWriter out=response.getWriter();
        HttpSession session = request.getSession();
        session.setAttribute("student",new Student("张天宇",99));
        //获取session类型为对象
        Student student = (Student) session.getAttribute("student");
        student.say();
        out.println(student.getName()+student.getAge());
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
```

- **对象**

```java
public class Student {
    private String name;
    private int age;

    public Student() {}

    public Student(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
    public void say(){
        System.out.println("我是"+name+"我今年"+age+"岁");
    }
}
```

