---
title: JavaWeb-Day-04
categories: 学习
tags: JavaWeb
---

## JSP

### 九大内置对象

- **pageContext**
- **request**
- **application**
- **session**
- **config**
- **out**
- **page**

#### 作用域

```jsp
<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html>
<head>
</head>
<body>
<%
    pageContext.setAttribute("name1","张天宇1");//保存的数据只在一个页面中有效
    request.setAttribute("name2","张天宇2");//保存的数据只在一次请求中有效，请求转发会携带
    application.setAttribute("name3","张天宇3");//保存的数据只在服务器中，从打开服务器到关闭服务器
    session.setAttribute("name4","张天宇4");//保存的数据只在一次会话中有效，从打开浏览器到关闭浏览器


%>
<%
    String name1 = (String) pageContext.findAttribute("name1");
    String name2 = (String) pageContext.findAttribute("name2");
    String name3 = (String) pageContext.findAttribute("name3");
    String name4 = (String) pageContext.findAttribute("name4");

%>

<h4>${name1}</h4>
<h4>${name2}</h4>
<h4>${name3}</h4>
<h4>${name4}</h4>

<%pageContext.forward("a.jsp");%>
</body>
</html>
```

- **jsp标签**

```jsp
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Title</title>
</head>
<body>
<%--转发并设置参数--%>
<jsp:forward page="/s2.jsp">
    <jsp:param name="age" value="10"></jsp:param>
</jsp:forward>
</body>
</html>

```

```jsp
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Title</title>
</head>
<body>

<%--获取参数--%>
年龄:<%=request.getParameter("age")%>
</body>
</html>
```

## JavaBean

实体类

JavaBean有特定的写法

- 必须要有一个无参构造
- 属性必须私有化
- 必须有get和set方法